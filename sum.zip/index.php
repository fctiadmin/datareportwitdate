<?php 
require 'admin_dbcon.php';


?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<form action="" method="POST"	class="date_by_report">
	<div class="row">
		<div class="col-lg-4 col-md-12 mb-3">
			<label class="form-label">Form</label>		
			<input type="date" class="form-control" name="form"/>			
		</div>
		<div class="col-lg-4 col-md-12 mb-3">
			<label class="form-label">To</label>		
			<input type="date" class="form-control" name="to"/>		
		</div>
		</div>
    <button type="submit" class="btn btn-primary" name="find_payment">Submit</button>
	
	
	</form>
	<br>
	<table border="1" cellspacing="0">
		<tr>
			<td>Slip No</td>
			<td>Roll No</td>
			<td>Student Name</td>
			<td>Amount</td>
			<td>Date</td>
		</tr>
		<?php
		if(isset($_POST['find_payment'])){
			$form=$_POST['form'];
			$to=$_POST['to'];

		
		 date_default_timezone_set("Asia/Dhaka");
		 $current_date=date('Y-m-d');
		$select_data=mysqli_query($admin_dbcon,"SELECT * FROM `payment` WHERE `payment_date` BETWEEN '$form' and '$to'");
		$today_amount_data_select=mysqli_query($admin_dbcon,"SELECT sum(amount) as total_amount FROM payment  WHERE `payment_date` BETWEEN '$form' and '$to'");

		$total_row=mysqli_fetch_assoc($today_amount_data_select);
		if(mysqli_num_rows($select_data)>0){
			while($rows=mysqli_fetch_assoc($select_data)){?>
				<tr>
				<td><?=$rows['slip_number']?></td>
					<td><?=$rows['roll']?></td>
					<td><?=$rows['student_name']?></td>
					<td><?=$rows['amount']?></td>
					<td><?=$rows['payment_date']?></td>
				</tr>
				
				<?php	
				}


		}else{
			echo "<script>
			alert('No Data Found');
			window.location.href='index.php';
			</script>";
		}
	
	
	}
		
		
		?>
		<tr>
		<td style="text-align:right" colspan="3">Total</td>
		<td  colspan="2"><?php if(isset($total_row['total_amount'])){
			echo $total_row['total_amount'];
		}?></td>
		</tr>
	</table>
</body>
</html>